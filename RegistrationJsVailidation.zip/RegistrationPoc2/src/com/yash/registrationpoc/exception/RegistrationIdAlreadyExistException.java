package com.yash.registrationpoc.exception;

/**
 * This is the runtime exception which occur when the entered registrationId is
 * already present in the database
 * 
 * @author shyam.patidar
 *
 */
public class RegistrationIdAlreadyExistException extends RuntimeException {
	public RegistrationIdAlreadyExistException(String message) {
		super(message);
	}
}
