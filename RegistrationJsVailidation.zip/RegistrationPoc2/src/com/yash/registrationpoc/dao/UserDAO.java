package com.yash.registrationpoc.dao;

import java.util.List;

import com.yash.registrationpoc.model.User;

/**
 * This interface perform the operation related to users.
 * @author shyam.patidar
 *
 */
public interface UserDAO {
	
	/**
	 * This will add the user into DB
	 * @param user Object
	 */
	public void insert(User user);
	
	/**
	 * This will List users from the users table from DB
	 * @return
	 */
	public List<User> list();

}
