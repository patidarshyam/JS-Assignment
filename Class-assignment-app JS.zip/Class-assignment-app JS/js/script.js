var assList = {
    assignments:[],
    addAssign:function(assignText){
        this.assignments.push({
        assignText:assignText,
        completed:false
    }); },
	deleteAssign:function(position){
		this.assignments.splice(position,1);
		},
//		toggleComplete:function(position){
//			var assignment = this.assignments[position];
//			assignment.completed=!assignment.completed;
//    },
};


var handlers={
	addAssign:function(){
		var assignTxtInput=document.getElementById('assignTxtInput');
		assList.addAssign(assignTxtInput.value);
		assignTxtInput.value='';
	//	view.displayAssign();
	},
	deleteAssign:function(){
		var position=document.getElementById('assignLocationDeleteInput');
		assList.deleteAssign(position);
		assignLocationDeleteInput.value='';
		//view.displayAssign();
	},
};

//var view={
//	displayAssign:function(){	
//	var assignTable=document.querySelector('table');
////		assignUl.innerHTML='';
//	if(assList.assignments.length===0){
//		var errorTr=document.createElement('tr');
//		var errorTd=document.createElement('td');
//		errorTd.textContent='There is no item to show!';
//		assignTr.appendChild(errorTd);
//		assignTable.appendChild(errorTr);
//   }else{
//	for(var i=0; i<assList.assignments.length;i++){
//		var assign=assList.assignments[i];
//		var assignTr=document.createElement('tr');
//		var assingTd=document.createElement('td');
//	
//		assignTd.textContent=assign.assignText;
//		
//		assignTd.appendChild(assingTd);
//		assignTable.appendChild(assignTd);
//	}
//	}
//	
//}
//};