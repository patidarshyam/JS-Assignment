var validate = {

	formValidator : function() {

		event.preventDefault();
		var letters = /^[_A-Z_a-z_ ]*$/;
		var name = document.forms["registerationForm"]["name"].value;
		var namespan = document.getElementById("namespan");

		var numbers = /^[0-9]+$/;
		var contact = document.forms["registerationForm"]["contact"].value;
		var contactspan = document.getElementById("contactspan");

		var email = document.forms["registerationForm"]["email"].value;
		var atPosition = email.indexOf("@");
		var dotPosition = email.lastIndexOf(".");
		var dotStr = email.substring(atPosition + 1, atPosition + 2);
		var emailspan = document.getElementById("emailspan");

		/* name validation */
		if (name.match(letters)) {
			if (name.length < 5 || 20 < name.length) {
				namespan.innerText = "Name field must contain atleast 5 letters and atmost 20 letters";
				document.registerationForm.name.focus();
				return false;
			}
		} else {
			namespan.innerText = "Please enter alphabet characters only";
			document.registerationForm.name.focus();
			return false;
		}

		/* contact validation */
		if (contact.match(numbers)) {
			if (contact.length != 10) {
				contactspan.innerText = "Contact should be of 10 digit numebers";
				document.registerationForm.name.focus();
				return false;
			}
		} else {
			contactspan.innerText = "Please enter valid contact number";
			document.registerationForm.name.focus();
			return false;
		}

		/* email validation
		 * /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)
		 * 
		 * /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/
		 *  */
		
		if (atPosition < 1 || dotPosition < (atPosition + 2)
				|| (dotPosition + 2) >= email.length || dotStr == "." || email.indexOf(' ') >= 0) {
			emailspan.innerText = "Enter proper e-mail address";
			document.registerationForm.email.focus();
			return false;
		}

		document.forms["registerationForm"].submit();
	},

}
