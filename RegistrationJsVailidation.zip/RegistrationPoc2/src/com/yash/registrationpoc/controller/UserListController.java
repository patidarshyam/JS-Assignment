package com.yash.registrationpoc.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.registrationpoc.model.User;
import com.yash.registrationpoc.service.UserService;
import com.yash.registrationpoc.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserListController
 * 
 * This Controller will handle the request for User list and will provide the
 * list of all registered User
 * 
 * @author shyam.patidar
 */
@WebServlet("/UserListController")
public class UserListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserListController() {
		super();
		userService = new UserServiceImpl();
	}

	/**
	 * This method of Controller will handle the request for User list and will
	 * provide the list of all registered User and redirect to welcome.jsp page
	 * where list will be displayed
	 */
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<User> users = userService.getAllUser();
		request.setAttribute("users", users);
		request.getRequestDispatcher("/welcome.jsp").forward(request, response);

	}
}
