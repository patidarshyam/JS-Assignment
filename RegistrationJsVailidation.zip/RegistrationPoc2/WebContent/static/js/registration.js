var registration = {
	regValidator : function(value) {
		event.preventDefault();
		/*
		 * AJAX call to UserRegistrationIdCheckController for checking the registrationId already present or not.
		 */
		$.ajax({
					type : "GET",
					url : "http://localhost:8080/RegistrationPoc/UserRegistrationIdCheckController",
					data : {
						'search_keyword' : value
					},
					dataType : "text",
					success : function(msg) {
						var span = document.getElementById("regIdspan");
						if (msg == "true") {
							/*
							 * Disabled the button if registrationId already present.
							 */
							document.getElementById("registerBtn").disabled = true;
							span.innerText = "RegistrationId already exist. Try again!";
						} else {
							document.getElementById("registerBtn").disabled = false;
							span.innerText = "";
						}
						
						document.registerationForm.registrationId.focus();

					}
				});
		return;
	}
}